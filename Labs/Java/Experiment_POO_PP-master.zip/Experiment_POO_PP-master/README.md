# Experiment - POO/PP
 Material repository for experiment of influence of the programming paradigm in a software project.
