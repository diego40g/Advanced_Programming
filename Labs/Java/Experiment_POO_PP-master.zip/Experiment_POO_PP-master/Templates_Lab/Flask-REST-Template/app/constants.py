
GET = ['GET']
POST = ['POST']
PUT = ['PUT']
