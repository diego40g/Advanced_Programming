# Spring-REST-Template
 Folder structure for a simple spring rest app
